function [y, x] = swap(x, y)
%SWAP  Swap two variables.
%
%   [a, b] = SWAP(x, y) sets A to Y and B to X.
end
