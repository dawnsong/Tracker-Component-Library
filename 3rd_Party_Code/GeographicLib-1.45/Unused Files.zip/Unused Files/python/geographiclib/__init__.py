"""geographiclib: geodesic routines from GeographicLib"""

__version_info__ = (1, 45, 0)
__version__ = "1.45"
